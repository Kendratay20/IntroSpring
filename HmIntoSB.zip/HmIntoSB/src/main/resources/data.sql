insert into Patients values (101, 'Johnson', 'Kendra');
insert into Patients values (102, 'KING', 'LARRY');