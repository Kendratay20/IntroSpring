package com.tts.HMIntrSB.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tts.HMIntrSB.demo.dao.PatientRepo;
import com.tts.HMIntrSB.demo.model.Patients;
 

@Controller
public class PatientsController {
	
	@Autowired
	PatientRepo repo;
	
	@RequestMapping("/")
	public String home()
	{
		return "home.jsp";
	}
	
	@RequestMapping("/addPatients")
	public String addPatient(Patients patients)
	{
		repo.save(patients);
		return "home.jsp";
	}

}
