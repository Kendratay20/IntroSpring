package com.tts.HMIntrSB.demo.dao;

import org.springframework.data.repository.CrudRepository;


import com.tts.HMIntrSB.demo.model.Patients;

public interface PatientRepo extends CrudRepository <Patients, Integer>
{
	
}
